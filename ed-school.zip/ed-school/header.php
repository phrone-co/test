<?php get_template_part( 'templates/head' ); ?>
<body <?php body_class(); ?>>
	<?php get_template_part( 'templates/header-mobile' ); ?>
	<?php get_template_part( 'templates/header' ); ?>
