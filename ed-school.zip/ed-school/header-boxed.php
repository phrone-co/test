<?php get_template_part( 'templates/head' ); ?>
<body <?php body_class( 'boxed' ); ?>>
	<?php get_template_part( 'templates/header-mobile' ); ?>
	<div class="wh-main-wrap">
		<?php get_template_part( 'templates/header' ); ?>
