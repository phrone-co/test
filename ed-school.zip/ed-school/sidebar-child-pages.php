<?php if ( is_active_sidebar( 'ed-school-sidebar-child-pages' ) ) : ?>
	<?php dynamic_sidebar( 'ed-school-sidebar-child-pages' ); ?>
<?php endif; ?>
