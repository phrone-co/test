<?php if ( is_active_sidebar( 'ed-school-sidebar-primary' ) ) : ?>
	<?php dynamic_sidebar( 'ed-school-sidebar-primary' ); ?>
<?php endif; ?>
