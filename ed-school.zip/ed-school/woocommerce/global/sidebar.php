<?php
/**
 * @version 5.0
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_sidebar( 'shop' ); ?>
