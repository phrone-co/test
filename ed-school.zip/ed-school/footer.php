<?php get_template_part( 'templates/footer' ); ?>
<?php wp_footer(); ?>
</body>
</html>
