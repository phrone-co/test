<?php ed_school_entry_meta(); ?>
