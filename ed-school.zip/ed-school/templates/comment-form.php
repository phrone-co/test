<div class="wh-comment-form"><?php comment_form(); ?></div>
